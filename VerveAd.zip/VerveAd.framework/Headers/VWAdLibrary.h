//
//  VWAdLibrary.h
//  VWAdLibrary
//
//  Copyright (c) 2014 Verve Wireless, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VWUserDemographics.h"

/*!
 * Name of string value in Info.plist containing the partner keyword used for ad requests.
 *
 * Partner keyword is used to allocate revenue for the ads you display, so it's very important
 * that you specify it unless you're also using Verve Content API.
 *
 * When using the Verve Content API, you should not set this value.
 */
#define kVWOnlineAdsKeyword @"kVWOnlineAdsKeyword"

/*!
 * Name of string value in Standard User Defaults containing the base URL used for ad requests.
 * Should be used only in conjunction with Verve Content API! Otherwise ignore.
 * Typically this will look something like:
 *
 *   https://adcel.vrvm.com/banner?b=dailyplanet&p=iphn
 *
 * This base URL should specify your Verve-assigned partner (b=) and portal (p=) keywords.
 *
 * When not using the Verve Content API, use kVWOnlineAdsKeyword
 * to specify your partner keyword and ignore this key.
 */
#define kVWOnlineAdsBaseURL @"kVWOnlineAdsBaseURL"

/*!
 * Following keys are used to set request parameters when using Google Mobile Ads SDK's mediation.
 * All parameters are optional. Default content category used is News and Information.
 * Pass parameters in following way:
 *
 * NSDictionary *extras = @{ kVWGADExtraContentCategoryIDKey: @(VWContentCategoryNewsAndInformation),
 *                           kVWGADExtraDisplayBlockIDKey: @(15995) };
 *
 * GADCustomEventExtras *customEventExtras = [[GADCustomEventExtras alloc] init];
 * [customEventExtras setExtras:extras forLabel:@"Verve Ad Network"];
 *
 * GADRequest *request = [GADRequest request];
 * [request registerAdNetworkExtras:customEventExtras];
 */
extern NSString * _Nonnull const kVWGADExtraContentCategoryIDKey;       // NSNumber
extern NSString * _Nonnull const kVWGADExtraDisplayBlockIDKey;          // NSNumber
extern NSString * _Nonnull const kVWGADExtraPartnerModuleIDKey;         // NSNumber
extern NSString * _Nonnull const kVWGADExtraPostalCodeKey;              // NSString
extern NSString * _Nonnull const kVWGADExtrasAllowVideoAutoPlayKey;     // NSNumber
extern NSString * _Nonnull const kVWGADExtrasAllowVideoAudioOnStartKey; // NSNumber
extern NSString * _Nonnull const kVWGADExtrasDurationKey;               // NSNumber
extern NSString * _Nonnull const kVWGADExtrasMinDurationKey;            // NSNumber
extern NSString * _Nonnull const kVWGADExtrasMaxDurationKey;            // NSNumber

@class VWAdRequest;
@class CLLocation;

typedef enum : NSUInteger {
  VWAdLogPrintLevelInfo,  // default
  VWAdLogPrintLevelWarning,
  VWAdLogPrintLevelError
} VWAdLogPrintLevel;

/*!
 * Possible values for SDK mode
 */
typedef NS_ENUM(NSUInteger, VWMode) {
  VWModeON, // default
  VWModeOFF
};

@protocol VWAdLibraryDelegate <NSObject>

@optional

/*!
 * Ad SDK will request authorization for location services at first instance it needs location.
 * It will ask for "When In Use" authorization first, if NSLocationWhenInUseUsageDescription key is set in info.plist.
 * It will ask for "Always Usage" at some later point in time, if both NSLocationAlwaysAndWhenInUseUsageDescription and NSLocationWhenInUseUsageDescription are set on iOS 11,
 * or NSLocationAlwaysUsageDescription on iOS 10 and below.
 * If appropriate info.plist keys are not set, SDK will not request authorization for location services by itself even if this method returns YES.
 * If you wish to disallow all authorization requests, implement this delegate method and return NO. If at some point later SDK
 * should be allowed to proceed with authorization request, just return YES.
 *
 * Ad SDK will call this method whenever it needs location but CLLocationManager's status equals NotDetermined.
 *
 */
- (BOOL)shouldAdSDKRequestAuthorizationForLocationServices;

/*!
 * Delegate method for more granular control than "shouldAdSDKRequestAuthorizationForLocationServices".
 * Return NO to disallow only "Always Usage" authorization request.
 */
- (BOOL)shouldAdSDKRequestAlwaysAuthorizationForLocationServices;

/*!
 * Delegate method for more granular control than "shouldAdSDKRequestAuthorizationForLocationServices".
 * Return NO to disallow only "When In Use" authorization request.
 */
- (BOOL)shouldAdSDKRequestWhenInUseAuthorizationForLocationServices;

@end


/**
 The VWAdLibrary class provides centralized point of control for parameters of the ad library.
 */
@interface VWAdLibrary : NSObject

/*!
 * Returns version number of the library.
 */
+ (nonnull NSString *)sdkVersion;

/*!
 * Implement application:performFetchWithCompletionHandler: method of your application's delegate
 * and call this method within it. If your application does not use background fetch itself,
 * just pass completionHandler block you got from application:performFetchWithCompletionHandler: method,
 * like this:
 *
 * -(void)application:(UIApplication *)application performFetchWithCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
 * {
 *   [VWAdLibrary performFetchWithCompletionHandler:completionHandler];
 * }
 *
 * Otherwise, you should pass your custom block here and use that block to be notified when library is done with processing.
 *
 */
+ (BOOL)performFetchWithCompletionHandler:(nonnull void (^)(UIBackgroundFetchResult))completionHandler;


/*!
 * Shared instance.
 */
+ (nonnull VWAdLibrary *)shared;

/*!
 * Set desired log print level. Default is .Info.
 */
- (void)setLogPrintLevel:(VWAdLogPrintLevel)level;

/*!
 * Set desired SDK mode. Default is .ON.
 */
- (void)setMode:(VWMode)mode;

/*!
 * Delegate.
 */
@property (nonatomic, weak, nullable) id<VWAdLibraryDelegate> delegate;

/*!
 * Partner keyword you specified in Info.plist file (kVWOnlineAdsKeyword). If you did not specify
 * partner keyword in Info.plist, you must set it here prior to creating any ad views. You can change
 * this at any time. Value set here has higher priority than what's in Info.plist.
 */
@property (nonatomic, copy, nullable) NSString *partnerKeyword;


/*!
 * Object you can optionally set to supply the SDK with demographic information
 */
@property (nonatomic, strong, nullable) VWUserDemographics *userDemographics;

/*!
 * Latest acquired location. Updated on init and applicationDidBecomeActive with 1km desired accuracy.
 * When location services are enabled, should never be nil, but might be outdated.
 */
@property (nonatomic, readonly, nullable) CLLocation *sessionLocation;

@end
