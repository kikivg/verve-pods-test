//
//  VWUserDemographics.h
//  VWAdLibrary
//
//  Copyright (c) 2017 Verve Wireless, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/*! 
 * Possible values for age range
 */
typedef NS_ENUM(NSUInteger, VWAgeRange) {
  VWAgeRangeUnder13,
  VWAgeRange13to17,
  VWAgeRange18to24,
  VWAgeRange25to34,
  VWAgeRange35to44,
  VWAgeRange45to54,
  VWAgeRange55to64,
  VWAgeRange65andOver,
  VWAgeRangeUnknown // default
};

/*!
 * Possible values for ethnicity
 */
typedef NS_ENUM(NSUInteger, VWEthnicity) {
  VWEthnicityAfrican,
  VWEthnicityAsian,
  VWEthnicityEuropean,
  VWEthnicityHispanic,
  VWEthnicityUnknown // default
};

/*!
 * Possible values for income range
 */
typedef NS_ENUM(NSUInteger, VWIncomeRange) {
  VWIncomeRangeLessThan25K,
  VWIncomeRange25to50K,
  VWIncomeRange50to75K,
  VWIncomeRange75to100K,
  VWIncomeRange100to150K,
  VWIncomeRange150to200K,
  VWIncomeRangeOver200K,
  VWIncomeRangeUnknown // default
};

/*!
 * Possible values for gender
 */
typedef NS_ENUM(NSUInteger, VWGender) {
  VWGenderFemale,
  VWGenderMale,
  VWGenderOther,
  VWGenderUnknown // default
};

/*!
 * Possible values for education
 */
typedef NS_ENUM(NSUInteger, VWEducation) {
  VWEducationNone,
  VWEducationHighSchool,
  VWEducationSomeCollege,
  VWEducationPostSecondary,
  VWEducationAssociate,
  VWEducationBachelors,
  VWEducationMasters,
  VWEducationDoctorate,
  VWEducationUnknown // default
};

/*!
 * Possible values for martial status
 */
typedef NS_ENUM(NSUInteger, VWMaritalStatus) {
  VWMaritalStatusDivorced,
  VWMaritalStatusMarried,
  VWMaritalStatusNeverMarried,
  VWMaritalStatusSeparated,
  VWMaritalStatusWidowed,
  VWMaritalStatusUnknown // default
};

@interface VWUserDemographics : NSObject

/*! Age */
@property (nonatomic, strong, nullable) NSNumber *age;

/*! Age range */
@property (nonatomic, assign) VWAgeRange ageRange;

/*! Birth date components */
@property (nonatomic, strong, nullable) NSDateComponents *birthDateComponents;

/*! Income */
@property (nonatomic, strong, nullable) NSNumber *income;

/*! Income range */
@property (nonatomic, assign) VWIncomeRange incomeRange;

/*! Ethnicity */
@property (nonatomic, assign) VWEthnicity ethnicity;

/*! Gender */
@property (nonatomic, assign) VWGender gender;

/*! Education */
@property (nonatomic, assign) VWEducation education;

/*! Martial status */
@property (nonatomic, assign) VWMaritalStatus maritalStatus;

/*! This property can be used for supplying additional demographic information (ex. job title, hobbies, etc.) */
@property (nonatomic, strong, nullable) NSDictionary *other;

@end
