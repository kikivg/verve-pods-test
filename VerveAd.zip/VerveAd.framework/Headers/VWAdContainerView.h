//
//  VWAdContainerView.h
//  VWAdLibrary
//
//  Created by Srdan Rasic on 03/06/16.
//  Copyright © 2016 Verve Wireless, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VWAdContainerView : UIView
@end
