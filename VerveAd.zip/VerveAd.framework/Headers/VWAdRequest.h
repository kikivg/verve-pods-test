//
//  VWAdRequest.h
//  VWAdLibrary
//
//  Copyright (c) 2014 Verve Wireless, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VWContentCategory.h"
#import "VWRequest.h"

/**
 Represents request for creating an ad.
 */
@interface VWAdRequest : VWRequest

@end
